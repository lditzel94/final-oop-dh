package city.types;

public enum EstateTypes {
    HOUSE, NEIGHBORHOOD
}
